INSERT INTO account (user_id, username, password, email)
VALUES (1, 'May Fernandes', 'robot123', 'robotizando@robot.com')
