Install RoboCorp Extension:
https://marketplace.visualstudio.com/items?itemName=robocorp.robocorp-code

Open the command palette - (Windows, Linux): ctrl-shift-P (macOS): cmd-shift-P

select the command Robocorp: Run Robot

Select the task to run (only if the robot contains more than one task).
tasks.robot

Descrição do Desafio RPA:
https://robocorp.com/docs/development-guide/browser/rpa-form-challenge

GitHub:
https://github.com/robocorp/example-rpa-form-challenge
