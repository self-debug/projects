Usando exemplos da lib KafkaLibrary iremos ver conectar, ler, produzir e buscar por mensagens no Kafka:
https://github.com/s4int/robotframework-KafkaLibrary

Para rodar o Kafka Localmente, foi usada como referencia a postagem do Robson Agapito: 
https://robsonagapito.medium.com/subindo-o-kafka-em-localhost-no-windows-288c66b1b71a

Em resumo:
1) git clone https://github.com/robsonagapito/kafka-windows-example.git
2) Acessar a pasta e executar 0-Zookeeper.bat
3) Esperar a execução acontecer e console ficar parado
4) Executar arquivo 1-Kafka.bat
5) Executar 2-CreateTopics.bat