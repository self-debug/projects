Usando as Libs Requests e RestInstance, vamos ver duas formas diferentes de lidar com APIs em Robot
https://github.com/MarketSquare/robotframework-requests

https://github.com/asyrjasalo/RESTinstance