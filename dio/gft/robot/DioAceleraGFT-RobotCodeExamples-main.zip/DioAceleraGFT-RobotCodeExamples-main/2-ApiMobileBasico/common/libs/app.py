
def welcome(name):                                                        
    return "Olá " + name + ", bem vindo ao curso de RobotFramework!" 

result = welcome("Diogo")
print(result)
